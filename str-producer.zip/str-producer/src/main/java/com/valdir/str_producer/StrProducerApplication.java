package com.valdir.str_producer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrProducerApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrProducerApplication.class, args);
	}

}
